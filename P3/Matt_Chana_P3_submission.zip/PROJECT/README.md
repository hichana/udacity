# OpenStreetMap - A Data Cleaning Case Study

Files:
* OpenStreetMap_CaseStudy.ipynb is the main report/project file
* exports folder hold csv exports and database
* samples folder holds osm sample file
* screenshots folder holds images used in report
* scripts folder holds all scripts for this project
